
# 🧠 Compliance Case Monitoring Dashboard (Snowflake + Power BI)

## 🔍 Overview
This project simulates how a Business Systems Analyst with data expertise drives a compliance analytics solution using Snowflake and Power BI.

---

## ✅ Project Goals
- Migrate legacy flat files and case data into Snowflake
- Create RAW → STAGE → CURATED schema layers
- Build SLA breach and case volume dashboards using Power BI

---

## 🧩 Phase 1: Business Analysis

### 🔸 Stakeholder Discovery
- Identified core personas: Compliance Leads, QA Heads, Risk Analysts
- Conducted JAD sessions to document current gaps and future state

### 🔸 Documentation
- Created **BRD** covering goals, KPIs, business rules
- Authored **FRD** with data mappings, field definitions, logic
- Defined **user stories** with acceptance criteria

---

## 🏗️ Phase 2: Data Engineering & Design

### 📊 Data Profiling
- Analyzed raw case exports for nulls, types, and cardinality  
- Documented insights for schema validation

### 🗂️ Schema Architecture
- RAW schema → Direct dumps from SFTP/API  
- STAGE schema → Cleaned, transformed, joined  
- CURATED schema → SLA metrics, KPIs, analyst views

### 📋 STTM
- Mapped raw fields to curated models with transformation rules
- Joined master data (analysts, alert types) for data integrity

---

## ✅ Phase 3: Dashboard Delivery

### 🧱 Power BI Dashboard
- Visuals: SLA Breaches, Alert Type Trends, Analyst Load
- Logic: DAX measures for SLA days, counts, filters
- Backend: Connected via DirectQuery to Snowflake CURATED views

---

## 📈 Architecture Flow

![Data Flow Diagram](insert_image_here.png)

---

## 🧾 Outcome
✔️ Delivered real-time SLA monitoring dashboard  
✔️ Improved visibility, reduced manual Excel work  
✔️ Audit-ready documentation for traceability

---

## 🛠️ Tools Used
**Snowflake**, **Power BI**, **SQL**, **DAX**, **Azure Data Factory**, **JIRA**, **Visio**

Created by: *Senior Business Data Analyst*  
Created on: 2025-07-25
